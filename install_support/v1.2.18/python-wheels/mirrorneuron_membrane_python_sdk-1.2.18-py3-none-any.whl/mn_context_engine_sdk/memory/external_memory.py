from __future__ import annotations

import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from .backend import detect_runtime_backend
from .forget_policy import (
    ForgetDecision,
    ForgetPolicyOptions,
    evaluate_forget_candidate,
    external_forget_options,
)
from .policy import is_private_text, role_allows, string_list, visibility


EXTERNAL_MEMORY_QUERY_SCHEMA_V1 = "mn.external_memory.query.v1"
EXTERNAL_MEMORY_UPDATE_SCHEMA_V1 = "mn.external_memory.update.v1"
EXTERNAL_MEMORY_FORGET_SCHEMA_V1 = "mn.external_memory.forget.v1"

DEFAULT_QDRANT_COLLECTION = "mn_memory"
DEFAULT_QDRANT_EMBEDDING_MODEL = "BAAI/bge-small-en"


@dataclass(frozen=True)
class ExternalMemoryConfig:
    namespace: str
    collection: str
    top_k: int
    filters: dict[str, Any] = field(default_factory=dict)
    embedding_model: str = DEFAULT_QDRANT_EMBEDDING_MODEL
    use_gpu: str = "auto"
    url: str = ""
    api_key: str = ""


@dataclass(frozen=True)
class ExternalMemoryQueryResult:
    items: list[dict[str, Any]]
    hit_count: int
    collection: str
    namespace: str
    candidate_item_ids: list[str]
    visibility_dropped_count: int
    warnings: list[str]
    debug: dict[str, Any] = field(default_factory=dict)


def query_external_memory_items(request: dict[str, Any]) -> ExternalMemoryQueryResult:
    warnings: list[str] = []
    config = external_memory_config(request)
    query = request.get("query") if isinstance(request.get("query"), dict) else {}
    agent_role = str(query.get("agent_role") or request.get("agent_role") or "")
    client = _make_qdrant_client(config, warnings)
    if client is None:
        return _empty_query_result(config, warnings, accelerator="unavailable")

    query_text = _query_text(request)
    if not query_text.strip():
        warnings.append("external_memory_empty_query")
        return _empty_query_result(config, warnings, accelerator="not_used")

    try:
        models = _qdrant_models()
        document = _qdrant_document(models, query_text, config, warnings)
        query_filter = _qdrant_filter(models, config)
        response = client.query_points(
            collection_name=config.collection,
            query=document,
            query_filter=query_filter,
            limit=config.top_k,
        )
    except Exception as exc:
        warnings.append(f"qdrant_query_failed: {type(exc).__name__}")
        return _empty_query_result(config, warnings, accelerator=_accelerator_for_options(config, []))

    points = _points(response)
    items: list[dict[str, Any]] = []
    visibility_dropped = 0
    for point in points:
        item = _point_to_item(point, config, warnings)
        if not item:
            continue
        if _allowed_external_item(item, agent_role, config.filters):
            items.append(item)
        else:
            visibility_dropped += 1
    candidate_ids = [str(item["id"]) for item in items]
    return ExternalMemoryQueryResult(
        items=items,
        hit_count=len(points),
        collection=config.collection,
        namespace=config.namespace,
        candidate_item_ids=candidate_ids,
        visibility_dropped_count=visibility_dropped,
        warnings=sorted(set(warnings)),
        debug=_external_debug(config, accelerator=_accelerator_for_options(config, [])),
    )


def update_external_memory_request(request: dict[str, Any]) -> dict[str, Any]:
    warnings: list[str] = []
    config = external_memory_config(request)
    operation = str(request.get("operation") or "upsert").strip().lower()
    if operation not in {"upsert", "supersede", "delete", "checkpoint"}:
        raise ValueError(f"unsupported external memory operation: {operation}")

    client = _make_qdrant_client(config, warnings)
    if client is None:
        return _update_response(config, operation, "unavailable", warnings)

    try:
        models = _qdrant_models()
        if operation == "delete":
            deleted = _delete_external_items(client, models, config, request)
            return _update_response(config, operation, "deleted", warnings, deleted_ids=deleted)

        _ensure_collection(client, models, config, warnings)
        normalized = _normalized_update_items(request.get("items", []), operation, config, warnings)
        superseded = _mark_superseded_items(client, config, normalized, warnings) if operation == "supersede" else []
        upserted = _upsert_external_items(client, models, config, normalized, warnings)
        return _update_response(
            config,
            operation,
            "updated",
            warnings,
            upserted_ids=upserted,
            superseded_ids=superseded,
        )
    except Exception as exc:
        warnings.append(f"qdrant_update_failed: {type(exc).__name__}")
        return _update_response(config, operation, "failed", warnings)


def forget_external_memory_request(request: dict[str, Any]) -> dict[str, Any]:
    warnings: list[str] = []
    config = external_memory_config(request)
    options = external_forget_options(request)
    mode = str(request.get("mode") or "dry_run").strip().lower()
    if mode not in {"dry_run", "tombstone"}:
        raise ValueError(f"unsupported external memory forget mode: {mode}")
    if options.task_profile == "compliance" and mode == "tombstone":
        warnings.append("compliance_profile_forces_dry_run")
        mode = "dry_run"

    client = _make_qdrant_client(config, warnings)
    if client is None:
        return _forget_response(config, mode, "unavailable", warnings)

    try:
        models = _qdrant_models()
        points = _scroll_forget_candidates(client, models, config, request, warnings)
        current_task = _query_text(request)
        decisions = [_forget_decision_from_point(point, config, current_task, options, warnings) for point in points]
        decisions = [decision for decision in decisions if decision is not None]
        candidates = [decision for decision in decisions if decision.should_forget]
        skipped = [decision for decision in decisions if decision.protected_reasons]
        tombstoned_ids: list[str] = []
        if mode == "tombstone" and candidates:
            tombstoned_ids = _tombstone_external_items(client, config, candidates, warnings)
        status = "tombstoned" if mode == "tombstone" else "dry_run"
        return _forget_response(
            config,
            mode,
            status,
            warnings,
            decisions=decisions,
            candidate_ids=[decision.item_id for decision in candidates],
            skipped_protected_ids=[decision.item_id for decision in skipped],
            tombstoned_ids=tombstoned_ids,
        )
    except Exception as exc:
        warnings.append(f"qdrant_forget_failed: {type(exc).__name__}")
        return _forget_response(config, mode, "failed", warnings)


def external_memory_config(request: dict[str, Any]) -> ExternalMemoryConfig:
    external = request.get("external_memory") if isinstance(request.get("external_memory"), dict) else {}
    filters = external.get("filters") if isinstance(external.get("filters"), dict) else {}
    retrieval_options = request.get("retrieval_options") if isinstance(request.get("retrieval_options"), dict) else {}
    return ExternalMemoryConfig(
        namespace=str(
            external.get("namespace")
            or request.get("namespace")
            or os.environ.get("MN_QDRANT_NAMESPACE")
            or "default"
        ),
        collection=str(external.get("collection") or os.environ.get("MN_QDRANT_COLLECTION") or DEFAULT_QDRANT_COLLECTION),
        top_k=max(1, int(external.get("top_k") or request.get("top_k") or 80)),
        filters=dict(filters),
        embedding_model=str(
            external.get("embedding_model")
            or os.environ.get("MN_QDRANT_EMBEDDING_MODEL")
            or DEFAULT_QDRANT_EMBEDDING_MODEL
        ),
        use_gpu=str(external.get("use_gpu") or retrieval_options.get("use_gpu") or "auto").strip().lower(),
        url=str(external.get("url") or os.environ.get("MN_QDRANT_URL") or ""),
        api_key=str(external.get("api_key") or os.environ.get("MN_QDRANT_API_KEY") or ""),
    )


def _empty_query_result(
    config: ExternalMemoryConfig,
    warnings: list[str],
    *,
    accelerator: str,
) -> ExternalMemoryQueryResult:
    return ExternalMemoryQueryResult(
        items=[],
        hit_count=0,
        collection=config.collection,
        namespace=config.namespace,
        candidate_item_ids=[],
        visibility_dropped_count=0,
        warnings=sorted(set(warnings)),
        debug=_external_debug(config, accelerator=accelerator),
    )


def _make_qdrant_client(config: ExternalMemoryConfig, warnings: list[str]) -> Any | None:
    if not config.url:
        warnings.append("qdrant_not_configured: set MN_QDRANT_URL or external_memory.url")
        return None
    try:
        from qdrant_client import QdrantClient
    except Exception:
        warnings.append("qdrant_client_unavailable: install qdrant extra")
        return None
    kwargs: dict[str, Any] = {"url": config.url}
    if config.api_key:
        kwargs["api_key"] = config.api_key
    batch_size = _int_env("MN_QDRANT_BATCH_SIZE")
    if batch_size:
        kwargs["local_inference_batch_size"] = batch_size
    return QdrantClient(**kwargs)


def _qdrant_models() -> Any:
    from qdrant_client import models

    return models


def _query_text(request: dict[str, Any]) -> str:
    query = request.get("query") if isinstance(request.get("query"), dict) else {}
    parts = [
        str(query.get("current_task") or request.get("current_task") or ""),
        str(query.get("focus_id") or request.get("focus_id") or ""),
    ]
    working_items = request.get("working_items")
    if isinstance(working_items, list):
        for item in working_items[:12]:
            if isinstance(item, dict):
                parts.append(str(item.get("text") or item.get("summary") or item.get("content") or ""))
    return " ".join(part for part in parts if part).strip()


def _qdrant_document(models: Any, text: str, config: ExternalMemoryConfig, warnings: list[str]) -> Any:
    options = _fastembed_options(config, warnings)
    if options:
        return models.Document(text=text, model=config.embedding_model, options=options)
    return models.Document(text=text, model=config.embedding_model)


def _qdrant_filter(models: Any, config: ExternalMemoryConfig) -> Any | None:
    must = [models.FieldCondition(key="namespace", match=models.MatchValue(value=config.namespace))]
    must_not: list[Any] = []
    filters = config.filters
    filter_visibility = string_list(filters.get("visibility"))
    if filter_visibility:
        must.append(models.FieldCondition(key="visibility", match=models.MatchAny(any=filter_visibility)))
    kinds = string_list(filters.get("kind"))
    if kinds:
        must.append(models.FieldCondition(key="kind", match=models.MatchAny(any=kinds)))
    source_refs = string_list(filters.get("source_refs"))
    if source_refs:
        must.append(models.FieldCondition(key="source_refs", match=models.MatchAny(any=source_refs)))
    if not _truthy(filters.get("include_forgotten")):
        must_not.append(models.FieldCondition(key="status", match=models.MatchValue(value="forgotten")))
    return models.Filter(must=must, must_not=must_not) if must or must_not else None


def _fastembed_options(config: ExternalMemoryConfig, warnings: list[str]) -> dict[str, Any]:
    options: dict[str, Any] = {"lazy_load": True}
    accelerator = _accelerator_for_options(config, warnings)
    if accelerator == "cuda":
        options["cuda"] = True
    return options


def _accelerator_for_options(config: ExternalMemoryConfig, warnings: list[str]) -> str:
    if config.use_gpu in {"0", "false", "no", "off", "cpu"}:
        return "cpu"
    preferred = "cuda" if config.use_gpu in {"1", "true", "yes", "cuda", "gpu"} else os.environ.get("MN_CONTEXT_DEVICE", "auto")
    backend = detect_runtime_backend(preferred)
    if backend.device == "cuda":
        return "cuda"
    if config.use_gpu in {"1", "true", "yes", "cuda", "gpu"}:
        warnings.append("qdrant_cuda_requested_unavailable")
    return "cpu"


def _points(response: Any) -> list[Any]:
    points = getattr(response, "points", response)
    return points if isinstance(points, list) else list(points or [])


def _point_to_item(point: Any, config: ExternalMemoryConfig, warnings: list[str]) -> dict[str, Any] | None:
    payload = _payload(point)
    text = str(payload.get("text") or payload.get("document") or payload.get("summary") or payload.get("content") or "").strip()
    memory_id = str(payload.get("memory_id") or payload.get("id") or getattr(point, "id", "") or "")
    if not text:
        warnings.append(f"external_memory_hit_missing_text: {memory_id or 'unknown'}")
        return None
    if payload.get("superseded_by") and "superseded" not in text.lower():
        text = f"Superseded memory: {text}"
    metadata = dict(payload.get("metadata") or {})
    metadata.update(
        {
            "external_memory": True,
            "qdrant_point_id": str(getattr(point, "id", "")),
            "namespace": str(payload.get("namespace") or config.namespace),
            "semantic_score": _score(point),
            "updated_at": str(payload.get("updated_at") or ""),
            "supersedes": string_list(payload.get("supersedes")),
            "superseded_by": str(payload.get("superseded_by") or ""),
            "status": str(payload.get("status") or ""),
        }
    )
    return {
        "id": memory_id or str(getattr(point, "id", "")),
        "text": text,
        "kind": str(payload.get("kind") or "evidence"),
        "source_refs": string_list(payload.get("source_refs") or payload.get("source_ref")),
        "visibility": str(payload.get("visibility") or "shared"),
        "agent_id": str(payload.get("agent_id") or ""),
        "agent_role": str(payload.get("agent_role") or ""),
        "allowed_roles": string_list(payload.get("allowed_roles")),
        "importance": _float(payload.get("importance"), 0.0),
        "created_at": str(payload.get("created_at") or ""),
        "updated_at": str(payload.get("updated_at") or ""),
        "supersedes": string_list(payload.get("supersedes")),
        "superseded_by": str(payload.get("superseded_by") or ""),
        "status": str(payload.get("status") or ""),
        "retention_policy": str(payload.get("retention_policy") or ""),
        "legal_hold": payload.get("legal_hold", False),
        "protected": payload.get("protected", False),
        "metadata": metadata,
    }


def _payload(point: Any) -> dict[str, Any]:
    if isinstance(point, dict):
        value = point.get("payload") or {}
    else:
        value = getattr(point, "payload", {}) or {}
    return dict(value) if isinstance(value, dict) else {}


def _score(point: Any) -> float:
    value = point.get("score") if isinstance(point, dict) else getattr(point, "score", 0.0)
    return _float(value, 0.0)


def _allowed_external_item(item: dict[str, Any], agent_role: str, filters: dict[str, Any]) -> bool:
    metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
    status = str(item.get("status") or metadata.get("status") or "").lower()
    if not _truthy(filters.get("include_forgotten")) and status == "forgotten":
        return False
    item_visibility = visibility(item.get("visibility"))
    if item_visibility.value not in (string_list(filters.get("visibility")) or [item_visibility.value]):
        return False
    if item_visibility.value == "private" or is_private_text(str(item.get("text") or "")):
        return False
    if item_visibility.value == "role_scoped" and not role_allows(item, agent_role):
        return False
    kinds = string_list(filters.get("kind"))
    if kinds and str(item.get("kind") or "") not in kinds:
        return False
    source_refs = set(string_list(filters.get("source_refs")))
    if source_refs and not (source_refs & set(string_list(item.get("source_refs")))):
        return False
    return True


def _normalized_update_items(
    raw_items: Any,
    operation: str,
    config: ExternalMemoryConfig,
    warnings: list[str],
) -> list[dict[str, Any]]:
    items = raw_items if isinstance(raw_items, list) else []
    if raw_items is not None and not isinstance(raw_items, list):
        warnings.append("external_memory_items_not_list")
    normalized: list[dict[str, Any]] = []
    now = _now()
    for idx, raw in enumerate(items):
        if not isinstance(raw, dict):
            warnings.append(f"external_memory_item_not_object: index={idx}")
            continue
        memory_id = str(raw.get("id") or raw.get("memory_id") or f"memory_{idx}")
        text = " ".join(str(raw.get("text") or raw.get("summary") or raw.get("content") or "").split())
        if not text:
            warnings.append(f"external_memory_item_empty_text: {memory_id}")
            continue
        source_refs = string_list(raw.get("source_refs") or raw.get("source_ref"))
        if not source_refs:
            warnings.append(f"external_memory_source_refs_missing: {memory_id}")
        kind = str(raw.get("kind") or ("checkpoint" if operation == "checkpoint" else "evidence"))
        metadata = dict(raw.get("metadata") or {})
        payload = {
            "memory_id": memory_id,
            "id": memory_id,
            "namespace": config.namespace,
            "text": text,
            "document": text,
            "kind": kind,
            "source_refs": source_refs,
            "visibility": str(raw.get("visibility") or "shared"),
            "allowed_roles": string_list(raw.get("allowed_roles")),
            "agent_id": str(raw.get("agent_id") or ""),
            "agent_role": str(raw.get("agent_role") or ""),
            "importance": _float(raw.get("importance"), 0.0),
            "created_at": str(raw.get("created_at") or now),
            "updated_at": now,
            "supersedes": string_list(raw.get("supersedes") or metadata.get("supersedes")),
            "superseded_by": str(raw.get("superseded_by") or metadata.get("superseded_by") or ""),
            "status": str(raw.get("status") or "active"),
            "metadata": metadata,
        }
        normalized.append(payload)
    return normalized


def _ensure_collection(client: Any, models: Any, config: ExternalMemoryConfig, warnings: list[str]) -> None:
    try:
        client.get_collection(config.collection)
        return
    except Exception:
        pass
    try:
        vector_size = client.get_embedding_size(config.embedding_model)
        client.create_collection(
            collection_name=config.collection,
            vectors_config=models.VectorParams(size=vector_size, distance=models.Distance.COSINE),
        )
    except Exception as exc:
        warnings.append(f"qdrant_collection_ensure_failed: {type(exc).__name__}")


def _upsert_external_items(
    client: Any,
    models: Any,
    config: ExternalMemoryConfig,
    payloads: list[dict[str, Any]],
    warnings: list[str],
) -> list[str]:
    options = _fastembed_options(config, warnings)
    points = [
        models.PointStruct(
            id=_point_id(config.namespace, str(payload["memory_id"])),
            vector=models.Document(text=str(payload["text"]), model=config.embedding_model, options=options),
            payload=payload,
        )
        for payload in payloads
    ]
    if not points:
        return []
    if hasattr(client, "upsert"):
        client.upsert(collection_name=config.collection, points=points)
    else:
        client.upload_points(collection_name=config.collection, points=points)
    return [str(payload["memory_id"]) for payload in payloads]


def _mark_superseded_items(
    client: Any,
    config: ExternalMemoryConfig,
    payloads: list[dict[str, Any]],
    warnings: list[str],
) -> list[str]:
    superseded: list[str] = []
    for payload in payloads:
        new_id = str(payload["memory_id"])
        old_ids = string_list(payload.get("supersedes"))
        if not old_ids:
            continue
        points = [_point_id(config.namespace, old_id) for old_id in old_ids]
        try:
            client.set_payload(
                collection_name=config.collection,
                payload={"superseded_by": new_id, "status": "superseded", "updated_at": _now()},
                points=points,
            )
            superseded.extend(old_ids)
        except Exception as exc:
            warnings.append(f"qdrant_supersede_failed: {type(exc).__name__}")
    return sorted(set(superseded))


def _delete_external_items(client: Any, models: Any, config: ExternalMemoryConfig, request: dict[str, Any]) -> list[str]:
    ids = string_list(request.get("ids"))
    raw_items = request.get("items")
    if isinstance(raw_items, list):
        ids.extend(
            str(item.get("id") or item.get("memory_id"))
            for item in raw_items
            if isinstance(item, dict) and (item.get("id") or item.get("memory_id"))
        )
    ids = sorted(set(item for item in ids if item))
    point_ids = [_point_id(config.namespace, memory_id) for memory_id in ids]
    if point_ids:
        selector = models.PointIdsList(points=point_ids)
        client.delete(collection_name=config.collection, points_selector=selector)
    return ids


def _scroll_forget_candidates(
    client: Any,
    models: Any,
    config: ExternalMemoryConfig,
    request: dict[str, Any],
    warnings: list[str],
) -> list[Any]:
    max_candidates = max(1, int(request.get("max_candidates") or 1000))
    if not hasattr(client, "scroll"):
        warnings.append("qdrant_scroll_unavailable")
        return []
    response = client.scroll(
        collection_name=config.collection,
        scroll_filter=_forget_scroll_filter(models, config, request),
        limit=max_candidates,
        with_payload=True,
        with_vectors=False,
    )
    if isinstance(response, tuple):
        points = response[0]
    else:
        points = getattr(response, "points", response)
    return list(points or [])[:max_candidates]


def _forget_scroll_filter(models: Any, config: ExternalMemoryConfig, request: dict[str, Any]) -> Any:
    filters = request.get("filters") if isinstance(request.get("filters"), dict) else {}
    must = [models.FieldCondition(key="namespace", match=models.MatchValue(value=config.namespace))]
    kinds = string_list(filters.get("kind"))
    if kinds:
        must.append(models.FieldCondition(key="kind", match=models.MatchAny(any=kinds)))
    must_not = [models.FieldCondition(key="status", match=models.MatchValue(value="forgotten"))]
    return models.Filter(must=must, must_not=must_not)


def _forget_decision_from_point(
    point: Any,
    config: ExternalMemoryConfig,
    current_task: str,
    options: ForgetPolicyOptions,
    warnings: list[str],
) -> ForgetDecision | None:
    item = _point_to_item(point, config, warnings)
    if not item:
        return None
    return evaluate_forget_candidate(
        item,
        text=str(item.get("text") or ""),
        kind=str(item.get("kind") or ""),
        node_type=None,
        current_task=current_task,
        options=options,
    )


def _tombstone_external_items(
    client: Any,
    config: ExternalMemoryConfig,
    decisions: list[ForgetDecision],
    warnings: list[str],
) -> list[str]:
    tombstoned: list[str] = []
    for decision in decisions:
        if not decision.item_id:
            continue
        try:
            client.set_payload(
                collection_name=config.collection,
                payload={
                    "status": "forgotten",
                    "forgotten_at": _now(),
                    "forget_policy_id": "conservative_v1",
                    "forget_confidence": round(decision.confidence, 4),
                    "forget_reasons": list(decision.reasons),
                },
                points=[_point_id(config.namespace, decision.item_id)],
            )
            tombstoned.append(decision.item_id)
        except Exception as exc:
            warnings.append(f"qdrant_tombstone_failed: {decision.item_id}: {type(exc).__name__}")
    return sorted(set(tombstoned))


def _point_id(namespace: str, memory_id: str) -> str:
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"mn-external-memory:{namespace}:{memory_id}"))


def _update_response(
    config: ExternalMemoryConfig,
    operation: str,
    status: str,
    warnings: list[str],
    *,
    upserted_ids: list[str] | None = None,
    superseded_ids: list[str] | None = None,
    deleted_ids: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": EXTERNAL_MEMORY_UPDATE_SCHEMA_V1,
        "operation": operation,
        "external_memory": {
            "status": status,
            "namespace": config.namespace,
            "collection": config.collection,
            "upserted_ids": upserted_ids or [],
            "superseded_ids": superseded_ids or [],
            "deleted_ids": deleted_ids or [],
            "warnings": sorted(set(warnings)),
        },
    }


def _forget_response(
    config: ExternalMemoryConfig,
    mode: str,
    status: str,
    warnings: list[str],
    *,
    decisions: list[ForgetDecision] | None = None,
    candidate_ids: list[str] | None = None,
    skipped_protected_ids: list[str] | None = None,
    tombstoned_ids: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "schema_version": EXTERNAL_MEMORY_FORGET_SCHEMA_V1,
        "mode": mode,
        "external_memory": {
            "status": status,
            "namespace": config.namespace,
            "collection": config.collection,
            "candidate_ids": candidate_ids or [],
            "skipped_protected_ids": skipped_protected_ids or [],
            "tombstoned_ids": tombstoned_ids or [],
            "warnings": sorted(set(warnings)),
            "decisions": [decision.to_dict() for decision in decisions or []],
        },
    }


def _external_debug(config: ExternalMemoryConfig, accelerator: str) -> dict[str, Any]:
    return {
        "namespace": config.namespace,
        "collection": config.collection,
        "embedding_model": config.embedding_model,
        "top_k": config.top_k,
        "accelerator": accelerator,
    }


def _now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _int_env(name: str) -> int | None:
    value = os.environ.get(name)
    if not value:
        return None
    try:
        return int(value)
    except ValueError:
        return None


def _float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


# Private aliases preserve the names used by the optimizer during migration.
_visibility = visibility
_role_allows = role_allows
_is_private_text = is_private_text
_string_list = string_list
