from __future__ import annotations

import os
import platform
from dataclasses import dataclass, field


@dataclass(frozen=True)
class RuntimeBackend:
    workers: int
    accelerator: str
    device: str
    torch_available: bool
    supports_gpu: bool
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, object]:
        return {
            "workers": self.workers,
            "accelerator": self.accelerator,
            "device": self.device,
            "torch_available": self.torch_available,
            "supports_gpu": self.supports_gpu,
            "platform": platform.platform(),
            "notes": self.notes,
        }


def resolve_worker_count(workers: int | None = None) -> int:
    if workers is None:
        env_value = os.environ.get("MN_CONTEXT_WORKERS")
        if env_value:
            try:
                workers = int(env_value)
            except ValueError:
                workers = None
    if workers is None or workers <= 0:
        return max(1, os.cpu_count() or 1)
    return max(1, workers)


def detect_runtime_backend(preferred_device: str | None = None, workers: int | None = None) -> RuntimeBackend:
    preferred = (preferred_device or os.environ.get("MN_CONTEXT_DEVICE") or "auto").strip().lower()
    notes: list[str] = []
    worker_count = resolve_worker_count(workers)

    try:
        import torch  # type: ignore
    except Exception:
        return RuntimeBackend(
            workers=worker_count,
            accelerator="cpu",
            device="cpu",
            torch_available=False,
            supports_gpu=False,
            notes=["torch_not_installed; using CPU-only deterministic NLP"],
        )

    cuda_available = bool(getattr(torch, "cuda", None) and torch.cuda.is_available())
    hip_version = getattr(getattr(torch, "version", object()), "hip", None)
    mps_backend = getattr(getattr(torch, "backends", object()), "mps", None)
    mps_available = bool(mps_backend and mps_backend.is_available())

    wants_cuda = preferred in {"auto", "cuda", "nvidia", "amd", "rocm", "hip", "gpu"}
    wants_mps = preferred in {"auto", "mps", "metal", "apple", "apple-silicon", "gpu"}

    if wants_cuda and cuda_available:
        accelerator = "rocm" if hip_version else "cuda"
        return RuntimeBackend(
            workers=worker_count,
            accelerator=accelerator,
            device="cuda",
            torch_available=True,
            supports_gpu=True,
            notes=[f"torch_{accelerator}_available"],
        )

    if wants_mps and mps_available:
        return RuntimeBackend(
            workers=worker_count,
            accelerator="mps",
            device="mps",
            torch_available=True,
            supports_gpu=True,
            notes=["torch_mps_available"],
        )

    if preferred not in {"auto", "cpu"}:
        notes.append(f"requested_device_unavailable: {preferred}")
    notes.append("using_cpu")
    return RuntimeBackend(
        workers=worker_count,
        accelerator="cpu",
        device="cpu",
        torch_available=True,
        supports_gpu=False,
        notes=notes,
    )
