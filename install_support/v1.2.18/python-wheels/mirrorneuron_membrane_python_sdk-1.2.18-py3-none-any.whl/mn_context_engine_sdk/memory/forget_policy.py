from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from .policy import string_list


DEFAULT_FORGET_CONFIDENCE_THRESHOLD = 0.92
HIGH_IMPORTANCE_THRESHOLD = 0.8

ORDINARY_FORGET_KINDS = {"evidence", "tool_result", "note"}
VALID_TASK_PROFILES = {"default", "time_critical", "debugging", "research", "long_running_project", "compliance"}
PROTECTED_KINDS = {
    "approval",
    "checkpoint",
    "constraint",
    "contradiction",
    "do_not_lose",
    "goal",
    "hard_constraint",
    "latest_instruction",
    "must_keep",
    "next_action",
    "user_goal",
}
CRITICAL_NODE_TYPE_VALUES = {
    "user_goal",
    "latest_instruction",
    "hard_constraint",
    "approval",
    "checkpoint",
    "contradiction",
    "do_not_lose",
    "next_action",
    "error",
}
LOW_VALUE_MARKERS = (
    "generic success",
    "no useful details",
    "chatted about",
    "processed 10 files successfully",
    "successfully",
)
PROFILE_TTL_DAYS = {
    "time_critical": 30,
    "debugging": 14,
    "research": 180,
    "long_running_project": 365,
}


@dataclass(frozen=True)
class ForgetPolicyOptions:
    enabled: bool = False
    task_profile: str = "default"
    confidence_threshold: float = DEFAULT_FORGET_CONFIDENCE_THRESHOLD
    working_memory_only: bool = True


@dataclass(frozen=True)
class ForgetDecision:
    item_id: str
    should_forget: bool
    confidence: float
    reasons: tuple[str, ...] = field(default_factory=tuple)
    protected_reasons: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            "item_id": self.item_id,
            "should_forget": self.should_forget,
            "confidence": round(self.confidence, 4),
            "reasons": list(self.reasons),
            "protected_reasons": list(self.protected_reasons),
        }


def forget_policy_options(request: dict[str, Any]) -> ForgetPolicyOptions:
    raw_policy = request.get("forget_policy")
    policy = raw_policy if isinstance(raw_policy, dict) else {}
    query = request.get("query") if isinstance(request.get("query"), dict) else {}
    return ForgetPolicyOptions(
        enabled=bool(policy.get("enabled", False)),
        task_profile=_task_profile(policy.get("task_profile") or query.get("task_profile") or request.get("task_profile")),
        confidence_threshold=_float(policy.get("confidence_threshold"), DEFAULT_FORGET_CONFIDENCE_THRESHOLD),
        working_memory_only=bool(policy.get("working_memory_only", True)),
    )


def external_forget_options(request: dict[str, Any]) -> ForgetPolicyOptions:
    return ForgetPolicyOptions(
        enabled=True,
        task_profile=_task_profile(request.get("task_profile")),
        confidence_threshold=_float(request.get("confidence_threshold"), DEFAULT_FORGET_CONFIDENCE_THRESHOLD),
        working_memory_only=False,
    )


def evaluate_forget_candidate(
    item: dict[str, Any],
    *,
    text: str,
    kind: str,
    node_type: Any,
    current_task: str,
    options: ForgetPolicyOptions,
    now: datetime | None = None,
) -> ForgetDecision:
    item_id = str(item.get("id") or item.get("memory_id") or "")
    metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
    protected_reasons = _protected_reasons(item, kind, node_type, metadata)
    if protected_reasons:
        return ForgetDecision(
            item_id=item_id,
            should_forget=False,
            confidence=0.0,
            protected_reasons=tuple(sorted(protected_reasons)),
        )

    reasons: list[str] = []
    confidence = 0.0
    status = str(item.get("status") or metadata.get("status") or "").strip().lower()
    if status == "forgotten":
        return ForgetDecision(item_id=item_id, should_forget=True, confidence=1.0, reasons=("already_forgotten",))
    if status == "superseded" or item.get("superseded_by") or metadata.get("superseded_by"):
        confidence += 0.8
        reasons.append("superseded")

    lower_text = text.lower()
    if any(marker in lower_text for marker in LOW_VALUE_MARKERS):
        confidence += 0.55
        reasons.append("low_value_marker")

    age_days = _age_days(item, metadata, now or datetime.now(timezone.utc))
    ttl_days = PROFILE_TTL_DAYS.get(options.task_profile)
    if ttl_days is not None and age_days is not None and age_days >= ttl_days:
        confidence += 0.5 if options.task_profile == "time_critical" else 0.35
        reasons.append(f"older_than_{ttl_days}_days")

    normalized_kind = kind.strip().lower()
    if normalized_kind in ORDINARY_FORGET_KINDS:
        confidence += 0.15
        reasons.append("ordinary_ephemeral_kind")

    importance = _float(item.get("importance") or metadata.get("importance"), 0.0)
    if importance <= 0.2:
        confidence += 0.15
        reasons.append("low_importance")

    source_refs = string_list(item.get("source_refs") or item.get("source_ref"))
    if source_refs:
        confidence -= 0.05
        reasons.append("source_refs_present")
    else:
        confidence += 0.1
        reasons.append("no_source_refs")

    if current_task and not (set(_terms(current_task)) & set(_terms(text))):
        confidence += 0.15
        reasons.append("low_task_overlap")

    confidence = max(0.0, min(1.0, confidence))
    should_forget = confidence >= options.confidence_threshold and bool(reasons)
    return ForgetDecision(
        item_id=item_id,
        should_forget=should_forget,
        confidence=confidence,
        reasons=tuple(reasons),
    )


def _protected_reasons(item: dict[str, Any], kind: str, node_type: Any, metadata: dict[str, Any]) -> list[str]:
    reasons: list[str] = []
    normalized_kind = kind.strip().lower()
    if normalized_kind in PROTECTED_KINDS:
        reasons.append("protected_kind")
    if _node_type_value(node_type) in CRITICAL_NODE_TYPE_VALUES:
        reasons.append("critical_node_type")
    importance = _float(item.get("importance") or metadata.get("importance"), 0.0)
    if importance >= HIGH_IMPORTANCE_THRESHOLD:
        reasons.append("high_importance")
    retention_policy = str(item.get("retention_policy") or metadata.get("retention_policy") or "").strip().lower()
    if retention_policy in {"keep", "never"}:
        reasons.append("retention_policy")
    if _truthy(item.get("legal_hold") or metadata.get("legal_hold")):
        reasons.append("legal_hold")
    if _truthy(item.get("protected") or metadata.get("protected")):
        reasons.append("explicitly_protected")
    status = str(item.get("status") or metadata.get("status") or "").strip().lower()
    if normalized_kind in {"error", "failure"} and status not in {"resolved", "superseded", "forgotten"}:
        reasons.append("unresolved_error")
    return reasons


def _task_profile(value: Any) -> str:
    profile = str(value or "default").strip().lower()
    return profile if profile in VALID_TASK_PROFILES else "default"


def _age_days(item: dict[str, Any], metadata: dict[str, Any], now: datetime) -> int | None:
    raw_date = item.get("updated_at") or item.get("created_at") or metadata.get("updated_at") or metadata.get("created_at")
    if not raw_date:
        return None
    parsed = _parse_datetime(str(raw_date))
    if parsed is None:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    return max(0, (now - parsed).days)


def _parse_datetime(raw: str) -> datetime | None:
    normalized = raw.strip()
    if not normalized:
        return None
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _node_type_value(node_type: Any) -> str:
    if node_type is None:
        return ""
    return str(getattr(node_type, "value", node_type)).strip().lower()


def _terms(text: str) -> list[str]:
    return [part for part in "".join(char.lower() if char.isalnum() else " " for char in text).split() if len(part) > 2]


def _truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default
