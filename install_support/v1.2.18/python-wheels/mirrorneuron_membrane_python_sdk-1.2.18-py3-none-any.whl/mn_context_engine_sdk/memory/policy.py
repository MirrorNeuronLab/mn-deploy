from __future__ import annotations

from enum import Enum
from typing import Any


class Visibility(str, Enum):
    SHARED = "shared"
    PRIVATE = "private"
    ROLE_SCOPED = "role_scoped"


PRIVATE_MARKERS = (
    "PRIVATE_AGENT_MEMORY",
    "hidden chain of thought",
    "private scratchpad",
    "local-only scoring",
)

PRIVATE_BOUNDARY_MARKERS = (
    "must",
    "never",
    "required",
    "forbidden",
    "do not",
    "don't",
    "not leak",
    "without approval",
    "approval required",
)


def visibility(value: Any) -> Visibility:
    raw = str(value or Visibility.SHARED.value).strip().lower()
    if raw == Visibility.PRIVATE.value:
        return Visibility.PRIVATE
    if raw == Visibility.ROLE_SCOPED.value:
        return Visibility.ROLE_SCOPED
    return Visibility.SHARED


def role_allows(item: dict[str, Any], agent_role: str) -> bool:
    allowed = string_list(item.get("allowed_roles"))
    item_role = str(item.get("agent_role") or "")
    if allowed:
        return bool(agent_role) and agent_role in allowed
    if item_role:
        return bool(agent_role) and item_role == agent_role
    return True


def is_private_text(text: str) -> bool:
    lowered = text.lower()
    has_private_marker = any(marker.lower() in lowered for marker in PRIVATE_MARKERS)
    if not has_private_marker:
        return False
    return not any(marker in lowered for marker in PRIVATE_BOUNDARY_MARKERS)


def string_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value] if value else []
    if isinstance(value, list):
        return [str(item) for item in value if str(item)]
    return [str(value)] if str(value) else []


# Private aliases keep older optimizer internals compatible during migration.
_visibility = visibility
_role_allows = role_allows
_is_private_text = is_private_text
_string_list = string_list
